export { route as default } from './index.js';
